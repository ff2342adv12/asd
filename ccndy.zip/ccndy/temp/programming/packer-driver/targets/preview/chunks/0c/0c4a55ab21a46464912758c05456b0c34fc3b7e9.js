System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///F:/cc/asd/ccndy/assets/script/wait.ts at runtime.
      throw new Error("SyntaxError: E:CocosDashboard\file:F:ccasdccndyassetsscriptwait.ts: Missing semicolon. (27:39)\n\n  25 |             this.label.string = arr[count];\n  26 |             this.label.\n> 27 |             if (count < arr.length - 1) {\n     |                                        ^\n  28 |                 count++;\n  29 |             }\n  30 |             else {");
    }
  };
});
//# sourceMappingURL=0c4a55ab21a46464912758c05456b0c34fc3b7e9.js.map