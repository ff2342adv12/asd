System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///F:/cc/asd/ccndy/assets/script/wait.ts at runtime.
      throw new Error(`SyntaxError: E:\CocosDashboard\file:\F:\cc\asd\ccndy\assets\script\wait.ts: Missing semicolon. (27:39)

  25 |             this.label.string = arr[count];
  26 |             this.label.
> 27 |             if (count < arr.length - 1) {
     |                                        ^
  28 |                 count++;
  29 |             }
  30 |             else {`);
    }
  };
});
//# sourceMappingURL=16508940484c02aa9c98367ae94926ff4d4d50bc.js.map