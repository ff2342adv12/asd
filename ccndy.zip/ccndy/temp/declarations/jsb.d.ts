/// <reference path="E:\CocosDashboard\resources\.editors\Creator\3.7.1\resources\resources\3d\engine\@types\jsb.d.ts"/>
